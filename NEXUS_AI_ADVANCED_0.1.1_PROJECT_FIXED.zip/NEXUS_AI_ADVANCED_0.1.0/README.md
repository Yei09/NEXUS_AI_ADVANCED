# NEXUS AI Advanced 0.1.0

Primera base Android nativa (Kotlin), sin root, `minSdk 26`, `targetSdk 35`.

## Implementado en esta etapa
- Interfaz Android y chat de comandos reales (no generativo).
- Consulta de batería, almacenamiento interno y RAM del sistema.
- Apertura de ajustes de Wi-Fi, Bluetooth y ajustes generales mediante intents del sistema.
- Memoria local cifrada con AES-256-GCM y clave Android Keystore.
- Registro local de acciones en el almacenamiento privado de la app.
- Parada de emergencia para tareas; esta versión no crea tareas en segundo plano.
- Sin permisos de Internet, contactos, SMS, accesibilidad ni archivos compartidos.

## No implementado todavía
- Modelo GGUF / llama.cpp: no incluido; el chat declara explícitamente que no es generativo.
- Control directo de radios Wi-Fi/Bluetooth: Android restringe esos cambios; se abren los ajustes del sistema.
- Accesibilidad, automatizaciones en segundo plano, importación de modelos y aprendizaje de habilidades.
- Firma release propia: el workflow produce APK debug firmado con clave de depuración del runner; release es unsigned. Para distribución estable se debe configurar una clave privada en GitHub Secrets.

## Compilación en GitHub Actions
Sube este proyecto a un repositorio GitHub y ejecuta el workflow `Build NEXUS AI Android APK` desde Actions. El workflow entrega un único APK debug firmado automáticamente por Gradle, instalable para pruebas. La clave debug cambia entre ejecuciones; no usar para actualizaciones persistentes ni publicación. Una firma release permanente requiere configurar una clave privada propia en GitHub Secrets.

## Identidad
Application ID: `com.nexusai.advanced.debug` para debug; `com.nexusai.advanced` para release.
