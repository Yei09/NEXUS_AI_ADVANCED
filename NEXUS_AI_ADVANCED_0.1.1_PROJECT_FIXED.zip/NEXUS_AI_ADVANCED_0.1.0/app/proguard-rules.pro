# No custom shrinking rules required in 0.1.0.
