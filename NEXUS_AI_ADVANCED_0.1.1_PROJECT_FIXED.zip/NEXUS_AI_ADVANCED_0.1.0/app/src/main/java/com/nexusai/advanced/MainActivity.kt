package com.nexusai.advanced

import android.app.Activity
import android.app.ActivityManager
import android.content.Intent
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import java.text.DateFormat
import java.util.Date

class MainActivity : Activity() {
    private lateinit var transcript: LinearLayout
    private lateinit var input: EditText
    private lateinit var memory: SecureMemory
    private var stopped = false
    private val bg = Color.rgb(8, 13, 24)
    private val panel = Color.rgb(18, 27, 44)
    private val cyan = Color.rgb(83, 216, 232)
    private val white = Color.rgb(235, 243, 250)
    private val muted = Color.rgb(153, 172, 194)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        memory = SecureMemory(this)
        buildUi()
        addMessage("NEXUS", "NEXUS AI Advanced 0.1.0 está activo. En esta versión puedo consultar datos del dispositivo, abrir ajustes permitidos y guardar recuerdos cifrados. El motor generativo local todavía no está integrado; no fingiré respuestas de IA.")
        logAction("Aplicación iniciada")
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(18, 22, 18, 12) }
        val header = TextView(this).apply {
            text = "N E X U S   A I\nADVANCED 0.1.0 · LOCAL CONTROL"
            setTextColor(cyan); textSize = 19f; typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(header)
        val status = TextView(this).apply { text = "●  Modo privado  |  Motor local: pendiente  |  Sin telemetría"; setTextColor(muted); textSize = 11f; setPadding(0, 8, 0, 14) }
        root.addView(status)

        val scroll = ScrollView(this).apply { isFillViewport = false }
        transcript = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(2, 4, 2, 12) }
        scroll.addView(transcript)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        input = EditText(this).apply {
            hint = "Escribe un comando o 'recordar: ...'"; setHintTextColor(muted); setTextColor(white)
            setBackgroundColor(panel); textSize = 15f; setPadding(14, 10, 14, 10); setSingleLine(false); maxLines = 3
        }
        root.addView(input, LinearLayout.LayoutParams(-1, -2))
        val send = makeButton("ENVIAR") { handleInput() }
        root.addView(send)

        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(makeButton("Batería") { addMessage("NEXUS", batteryInfo()) }, weightParams())
        row1.addView(makeButton("Almacenamiento") { addMessage("NEXUS", storageInfo()) }, weightParams())
        row1.addView(makeButton("RAM") { addMessage("NEXUS", ramInfo()) }, weightParams())
        root.addView(row1)
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row2.addView(makeButton("Wi-Fi") { openSettings(Settings.ACTION_WIFI_SETTINGS) }, weightParams())
        row2.addView(makeButton("Bluetooth") { openSettings(Settings.ACTION_BLUETOOTH_SETTINGS) }, weightParams())
        row2.addView(makeButton("Ajustes") { openSettings(Settings.ACTION_SETTINGS) }, weightParams())
        root.addView(row2)
        val row3 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row3.addView(makeButton("Recuerdos") { showMemories() }, weightParams())
        row3.addView(makeButton("Detener tareas") { stopped = true; addMessage("NEXUS", "Parada de emergencia activada. No hay tareas en segundo plano en esta versión."); logAction("Parada de emergencia") }, weightParams())
        root.addView(row3)
        setContentView(root)
    }

    private fun weightParams() = LinearLayout.LayoutParams(0, 46, 1f).apply { setMargins(3, 4, 3, 4) }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 11f; setTextColor(white); setBackgroundColor(panel); isAllCaps = false
        setOnClickListener { action() }
    }

    private fun addMessage(who: String, message: String) {
        val view = TextView(this).apply {
            text = "$who\n$message"; setTextColor(if (who == "TÚ") cyan else white); textSize = 14f
            setPadding(12, 10, 12, 10); setBackgroundColor(panel)
        }
        val lp = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 5, 0, 5) }
        transcript.addView(view, lp)
    }

    private fun handleInput() {
        val command = input.text.toString().trim()
        if (command.isEmpty()) return
        input.setText("")
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(input.windowToken, 0)
        addMessage("TÚ", command)
        if (stopped) stopped = false
        val lower = command.lowercase()
        val answer = when {
            lower == "bateria" || lower == "batería" -> batteryInfo()
            lower == "almacenamiento" -> storageInfo()
            lower == "ram" || lower == "memoria" -> ramInfo()
            lower == "wifi" -> { openSettings(Settings.ACTION_WIFI_SETTINGS); "Abriendo los ajustes de Wi-Fi." }
            lower == "bluetooth" -> { openSettings(Settings.ACTION_BLUETOOTH_SETTINGS); "Abriendo los ajustes de Bluetooth." }
            lower == "ajustes" -> { openSettings(Settings.ACTION_SETTINGS); "Abriendo los ajustes del sistema." }
            lower == "recuerdos" -> memory.all().ifEmpty { listOf("Todavía no has guardado recuerdos.") }.joinToString("\n• ", "• ")
            lower.startsWith("recordar:") -> {
                val note = command.substringAfter(":").trim()
                if (note.isBlank()) "Escribe el contenido después de 'recordar:'." else { memory.remember(note); logAction("Recuerdo guardado"); "Recuerdo guardado cifrado en este dispositivo." }
            }
            lower == "detener" -> { stopped = true; logAction("Parada solicitada"); "Parada de emergencia activada." }
            else -> "No tengo un modelo generativo integrado todavía, así que no voy a inventar una respuesta. En 0.1.0 puedes usar: batería, almacenamiento, RAM, Wi-Fi, Bluetooth, ajustes, recordar: texto, recuerdos o detener."
        }
        addMessage("NEXUS", answer)
    }

    private fun batteryInfo(): String {
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val status = registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val plugged = status?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
        val charging = if (plugged != 0) "conectado a carga" else "sin conexión a carga"
        return "Batería: ${if (pct >= 0) "$pct%" else "no disponible"} · $charging."
    }

    private fun storageInfo(): String {
        val stat = StatFs(Environment.getDataDirectory().path)
        val free = stat.availableBytes / (1024.0 * 1024 * 1024)
        val total = stat.totalBytes / (1024.0 * 1024 * 1024)
        return "Almacenamiento interno: ${"%.2f".format(free)} GB libres de ${"%.2f".format(total)} GB."
    }

    private fun ramInfo(): String {
        val info = ActivityManager.MemoryInfo()
        (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(info)
        return "RAM disponible para el sistema: ${info.availMem / (1024 * 1024)} MB. Umbral bajo: ${info.threshold / (1024 * 1024)} MB."
    }

    private fun openSettings(action: String) {
        runCatching { startActivity(Intent(action)) }
            .onSuccess { logAction("Ajustes abiertos: $action") }
            .onFailure { addMessage("NEXUS", "Android no permitió abrir esta pantalla: ${it.localizedMessage ?: "error"}") }
    }

    private fun showMemories() {
        val notes = memory.all()
        addMessage("NEXUS", if (notes.isEmpty()) "No hay recuerdos guardados." else notes.mapIndexed { i, s -> "${i + 1}. $s" }.joinToString("\n"))
    }

    private fun logAction(action: String) {
        runCatching {
            File(filesDir, "nexus_actions.log").appendText("${DateFormat.getDateTimeInstance().format(Date())} | $action\n")
        }
    }
}
